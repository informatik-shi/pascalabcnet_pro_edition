ABC Native — Qt — экспериментальная версия

Распакуйте архив целиком и запустите Launch.cmd.
Ночная тема включена по умолчанию.
F8 — проверить программу. F9 — запустить.
Когда программа ждёт Readln, введите значение в строке под консолью и нажмите Enter.
Кнопка «Остановить» завершает выполняемую программу.
Ошибки выполнения показываются на английском (EN) и русском (RU),
с кодом ошибки, строкой и столбцом исходника.

Поддерживаются integer, int64, real/double, boolean, string,
динамические массивы, записи, пользовательские функции и процедуры с var-параметрами,
условия if и циклы while, базовая математика, строки, List<T>, Stack<T>, Queue<T>
и текстовые файлы UTF-8. Для Stack<T>/Queue<T> добавьте uses Collections;
Примеры: examples/structures.pas, examples/files.pas, examples/collections.pas, examples/standard-library.pas,
examples/text-numbers.pas, examples/string-editing.pas.
Совместимость с PascalABC.NET частичная.
Установка .NET, Python или Qt для запуска этого пакета не требуется.
