﻿ABC Native — Qt — экспериментальная версия

Распакуйте архив целиком и запустите Launch.cmd.
Ночная тема включена по умолчанию.
F8 — проверить программу. F9 — запустить.
Когда программа ждёт Read/Readln, введите значение в строке под консолью и нажмите Enter.
Кнопка «Остановить» завершает выполняемую программу.
Ошибки выполнения показываются на английском (EN) и русском (RU),
с кодом ошибки, строкой и столбцом исходника.

Поддерживаются integer, int64, real/double, boolean, char, byte, shortint, smallint, word, longword, uint64, string,
динамические и двумерные прямоугольные массивы, записи, пользовательские функции и процедуры с var-параметрами,
условия if, циклы while/for/repeat и foreach по строкам/массивам/List<T>, break/continue, базовая математика, строки, List<T>, Stack<T>, Queue<T>,
DynArray<T>, SimpleSet<T>, AssocArray<K,V>, LinkedList<T>, LinkedListNode<T>, SingleNode<T> и текстовые файлы с выбором кодировки.
Для классов Collections добавьте uses Collections; Для ReadFileToEnd/WriteStringToFile — uses FilesOperations;
Примеры: examples/structures.pas, examples/files.pas, examples/collections.pas, examples/buffers.pas,
examples/associations.pas, examples/linked-lists.pas, examples/single-nodes.pas, examples/standard-library.pas,
examples/text-numbers.pas, examples/string-editing.pas, examples/nil-strings.pas, examples/directories.pas, examples/renames.pas, examples/text-files.pas, examples/text-methods.pas, examples/text-file-changes.pas, examples/loops.pas, examples/foreach.pas, examples/characters.pas, examples/file-operations.pas, examples/small-integers.pas, examples/unsigned-integers.pas, examples/random-arrays.pas, examples/reverse-shuffle.pas, examples/extended-math.pas, examples/array-output.pas, examples/bitwise.pas, examples/console-input.pas, examples/console-functions.pas, examples/unicode-output.pas, examples/matrices.pas.
Text/TextFile: Assign, Reset, Rewrite, Append, Read/Readln, Write/Writeln, Eof, Flush и Close.
Методы Text: ReadWord, ReadToEnd, Name/FullName, Write/Writeln, Print/Println, Erase/Rename и чтение значений.
Добавлены создание, удаление и переименование файлов и каталогов, работа с текущей папкой программы.
Строковый nil отличается от пустой строки; стандартные строковые операции учитывают это различие.
Процедурные значения: function/procedure, Func, Action, Predicate и короткие типы T->U; пример examples/callable-values.pas.
Типы параметров и результата проверяются до запуска; вызов nil даёт двуязычную ошибку.
Сохранённые функции принимают Select/Where/Zip и TrueTable; пример examples/library-callables.pas.
Лямбды и локальные захваты: examples/lambdas.pas.
Генераторы SeqGen/ArrGen/MatrGen/Iterate/SeqWhile: examples/generators.pas.
Декартово произведение и степени Cartesian/CartesianPower: examples/cartesian.pas.
Сочетания, перестановки и NextPermutation: examples/combinatorics.pas.
Индексы массивов, списков и матриц: examples/array-views.pas.
Строки и столбцы матриц, замена и обмен: examples/matrix-lines.pas.
Заполнение, форма, транспонирование и сравнение массивов: examples/array-operations.pas.
ConvertAll, Transform, Fill и ForEach: examples/collection-callbacks.pas.
Срезы матриц по индексам и включительным границам: examples/matrix-slices.pas.
Конструкторы Matr, MatrByRow и MatrByCol: examples/matrix-construction.pas.
Условные выражения if/then/else и ?: examples/conditional-expressions.pas.
Замена элементов и независимые копии массивов/List: examples/replace-copy.pas.
Поиск, вставка, удаление и диапазоны List: examples/list-ranges.pas.
Добавление и вставка диапазонов AddRange/InsertRange: examples/list-bulk-ranges.pas.
JoinToString, JoinIntoString и Flatten: examples/sequence-text-flatten.pas.
Sleep, Milliseconds и MillisecondsDelta: examples/timing.pas.
Конструкторы List, Capacity, EnsureCapacity и TrimExcess: examples/list-capacity.pas.
Фабрики Lst, LstInt и LstStr: examples/list-factories.pas.
Явные типы и пустой Lst: examples/explicit-list-types.pas.
Копирование списка в массив: examples/list-copy-to.pas.
Базовые классы и взаимные ссылки: examples/class-fields.pas.
Методы класса, Self и аргументы по умолчанию: examples/class-methods.pas.
Свойства класса с read/write: examples/class-properties.pas.
Конструкторы с параметрами: examples/class-constructors.pas.
Секции доступа и внешние тела методов: examples/class-external-methods.pas.
Начальные значения полей: examples/class-field-initializers.pas.
Короткие тела функций и методов: examples/short-class-bodies.pas.
Шестнадцатеричные числа $FF, $FF_FF и разделители 1_000_000: examples/numeric-literals.pas.
Текстовые файлы с BOM читаются как UTF-8, UTF-16LE/BE или UTF-32LE/BE.
Символы CP1251 и ANSI-алиасы: examples/windows-characters.pas.
Encoding, CP1251/ASCII/Unicode и выбор кодировки ReadAllText/WriteAllText: examples/text-encodings.pas.
DefaultEncoding изначально CP1251. Его смена и явные Encoding-перегрузки Text: examples/default-encoding.pas.
Для сохранения всех Unicode-символов выберите Encoding.UTF8/Unicode; полный API Encoding ещё переносится.
ReadAllLines/WriteAllLines с Encoding и WriteLines для последовательностей: examples/file-lines.pas.
ReadLines с поточным чтением, повторным обходом и break: examples/streaming-lines.pas.
Одновременные обходы одного ReadLines разделяют читателя, как в исходной библиотеке; закрытие одного закрывает поток другого.
OpenRead/Reset и Read/Readln/ReadToEnd читают Text по блокам: examples/streaming-text.pas.
ReadString(f) переходит на новую строку; Read(f,s) оставляет перевод строки.
Нативная запись Text, Rewrite с сохранением буфера и Append: examples/text-writer.pas.
Rewrite после Append непустого файла даёт E_IO; закройте файл и откройте заново.
Text.Lines сохраняет буфер при перемещении потока в начало: examples/text-lines.pas. Для чистого повторного чтения используйте Reset.
Полный интерфейс перечислителя ещё не перенесён.
Прямой захват управляющей переменной цикла пока не перенесён; используйте отдельную переменную-копию.
Совместимость с PascalABC.NET частичная.
Русские имена и НОД/НОК: examples/russian-identifiers.pas. Массивные GCD/LCM: examples/school-folds.pas.
Регистр и категории Unicode: examples/unicode-characters.pas. Правила регистра фиксированы таблицами Unicode 15.1.
Кортежи и НОДНОК: examples/tuples.pas. Минимум и максимум: examples/school-minmax.pas.
BigInteger: examples/big-integers.pas и examples/big-integer-files.pas. Числа ограничены 65536 битами.
Установка .NET, Python или Qt для запуска этого пакета не требуется.
