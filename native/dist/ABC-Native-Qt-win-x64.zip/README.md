ABC Native — Qt — экспериментальная версия

Распакуйте архив целиком и запустите Launch.cmd.
Ночная тема включена по умолчанию.
F8 — проверить программу. F9 — запустить.
Когда программа ждёт Readln, введите значение в строке под консолью и нажмите Enter.
Кнопка «Остановить» завершает выполняемую программу.
Ошибки выполнения показываются на английском (EN) и русском (RU),
с кодом ошибки, строкой и столбцом исходника.

Поддерживаются integer, int64, real/double, boolean, string,
динамические массивы, записи, пользовательские функции и процедуры с var-параметрами,
условия if и циклы while, базовая математика, строки, List<T>, Stack<T>, Queue<T>,
DynArray<T>, SimpleSet<T>, AssocArray<K,V>, LinkedList<T>, LinkedListNode<T>, SingleNode<T> и текстовые файлы UTF-8.
Для классов Collections добавьте uses Collections;
Примеры: examples/structures.pas, examples/files.pas, examples/collections.pas, examples/buffers.pas,
examples/associations.pas, examples/linked-lists.pas, examples/single-nodes.pas, examples/standard-library.pas,
examples/text-numbers.pas, examples/string-editing.pas, examples/nil-strings.pas, examples/directories.pas, examples/renames.pas.
Добавлены создание, удаление и переименование файлов и каталогов, работа с текущей папкой программы.
Строковый nil отличается от пустой строки; стандартные строковые операции учитывают это различие.
Совместимость с PascalABC.NET частичная.
Установка .NET, Python или Qt для запуска этого пакета не требуется.
