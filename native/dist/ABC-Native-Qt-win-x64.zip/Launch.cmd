@echo off
start "" "%~dp0bin\abc-ide.exe"

